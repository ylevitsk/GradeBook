//
//  ViewController.swift
//  GradebookExample
//
//  Created by John Bellardo on 2/13/15.
//  Copyright (c) 2015 John Bellardo. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet var tableView: UITableView!
    var items: [String] = []
    var details:[String] = []
    var term: String!
    var course: String!
    var json: JSON!
    var password =  String()
    var url =  String()
    var username = String()
    let shareData = ShareData.sharedInstance
    
    override func viewDidLoad() {
        super.viewDidLoad()
        term = self.shareData.term
        course = self.shareData.course
        password = self.shareData.password
        url = self.shareData.url
        username = self.shareData.username
        
        refreshData()
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    func refreshData() {
        let loader = GradebookURLLoader()
        
        // Live data URL
        //loader.baseURL = "https://users.csc.calpoly.edu/~bellardo/cgi-bin/grades.json"
        
        // Test data URL
        //loader.baseURL = "https://users.csc.calpoly.edu/~bellardo/cgi-bin/test/grades.json"
        //if loader.loginWithUsername("test", andPassword: "sadf35cx90") {
        loader.baseURL = url;
        if loader.loginWithUsername(username, andPassword: password) {
            println("Auth worked!")
            let data = loader.loadDataFromPath("?record=enrollments&term=" + term + "&course=" + course, error: nil)
            json = JSON(data: data)
            println("\(json)")
            let num = json["enrollments"].array?.count
            for i in 0...num!-1 {
                items.append(json["enrollments"][i]["id"].stringValue)
                details.append(json["enrollments"][i]["username"].stringValue)
            }
        }
        else {
            println("Auth failed!")
        }
    }
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count;
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var cell:UITableViewCell = self.tableView.dequeueReusableCellWithIdentifier("cell") as UITableViewCell
        
        cell.textLabel?.text = self.items[indexPath.row]
        cell.detailTextLabel?.text = self.details[indexPath.row]
        return cell
    }
    var index: Int!
    func tableView(tableView: UITableView!, didSelectRowAtIndexPath indexPath: NSIndexPath!) {
        let val = self.items[indexPath.row]
        println("You selected cell #\(indexPath.row)!")
        
        let num = json["enrollments"].array?.count
        for i in 0...num!-1 {
            if json["enrollments"][i]["id"].stringValue == val{
                index = i;
                break;
            }
        }
        self.shareData.user = json["enrollments"][index]["username"].stringValue
    }
}