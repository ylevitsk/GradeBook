//
//  ViewController.swift
//  GradebookExample
//
//  Created by John Bellardo on 2/13/15.
//  Copyright (c) 2015 John Bellardo. All rights reserved.
//

import UIKit

class FourthViewController: UIViewController, UISplitViewControllerDelegate { // UITableViewDelegate, UITableViewDataSource {
    @IBOutlet var tableView: UITableView!
    var items: [String] = []
    var details: [String] = []
    var term: String!
    var course: String!
    var json: JSON!
    var password =  String()
    var url =  String()
    var username = String()
    var id = Int()
    var user = String()
    let shareData = ShareData.sharedInstance

    var detailItem: Bool? {
        didSet {
            // Update the view.
            //self.configureView()
    
            //Comment out this if clause if you don't want the Master to disappear.
            /*if self.masterPopoverController != nil {
            self.masterPopoverController!.dismissPopoverAnimated(true)
            }*/
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        if splitViewController != nil {
            if splitViewController!.respondsToSelector(Selector("displayModeButtonItem")) {
                navigationItem.leftBarButtonItem = splitViewController!.displayModeButtonItem()
                navigationItem.leftItemsSupplementBackButton = true
            }
        }
        if let detail: Bool = self.detailItem {
            term = self.shareData.term
            course = self.shareData.course
            password = self.shareData.password
            url = self.shareData.url
            username = self.shareData.username
            id = self.shareData.id
            user = self.shareData.user
            self.title = "Scores"
            refreshData()
            
        }
        /*term = self.shareData.term
        course = self.shareData.course
        password = self.shareData.password
        url = self.shareData.url
        username = self.shareData.username
        id = self.shareData.id
        user = self.shareData.user
        
        refreshData()*/

        //tableView.delegate = self
        //tableView.dataSource = self
    }
    func refreshData() {
        let loader = GradebookURLLoader()
        
        // Live data URL
        //loader.baseURL = "https://users.csc.calpoly.edu/~bellardo/cgi-bin/grades.json"
        
        // Test data URL
        //loader.baseURL = "https://users.csc.calpoly.edu/~bellardo/cgi-bin/test/grades.json"
        //if loader.loginWithUsername("test", andPassword: "sadf35cx90") {
        loader.baseURL = url
        if loader.loginWithUsername(username, andPassword: password) {
            println("Auth worked!")
            //let data = loader.loadDataFromPath("?record=asnstats&term=" + term + "&course=" + course + "&id=" + id, error: nil)
            let data = loader.loadDataFromPath("?record=userscores&term=" + term + "&course=" + course + "&user=" + user, error: nil)
            json = JSON(data: data)
            println("\(json)")
            let num = json["userscores"][id]["scores"].array?.count
            for i in 0...num!-1 {
                items.append(json["userscores"][id]["scores"][i]["display_score"].stringValue)
                details.append(json["userscores"][id]["scores"][i]["score"].stringValue)
            }
        }
        else {
            println("Auth failed!")
        }
    }
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count;
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var cell:UITableViewCell = self.tableView.dequeueReusableCellWithIdentifier("cell") as UITableViewCell
        
        cell.textLabel?.text = self.items[indexPath.row]
        cell.detailTextLabel?.text = self.details[indexPath.row]
        return cell
    }
   /* var index: Int!
    func tableView(tableView: UITableView!, didSelectRowAtIndexPath indexPath: NSIndexPath!) {
        let val = self.items[indexPath.row]
        println("You selected cell #\(indexPath.row)!")
        
        let num = json["userscores"].array?.count
        for i in 0...num!-1 {
            if json["userscores"][i]["id"].stringValue == val{
                index = i;
                break;
            }
        }
        self.shareData.user = json["enrollments"][index]["usename"].stringValue
    }*/
    
}
