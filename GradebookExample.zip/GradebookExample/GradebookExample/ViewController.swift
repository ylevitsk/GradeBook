//
//  ViewController.swift
//  GradebookExample
//
//  Created by John Bellardo on 2/13/15.
//  Copyright (c) 2015 John Bellardo. All rights reserved.
//

import UIKit

class ViewController: UITableViewController, UISplitViewControllerDelegate{ //, UITableViewDelegate, UITableViewDataSource {
    //@IBOutlet var tableView: UITableView!
    
    var items: [String] = []
    var details: [String] = []
    var json: JSON!
    var password =  String()
    var url =  String()
    var username = String()
    let shareData = ShareData.sharedInstance
    var detailViewController: FourthViewController? = nil
    
    override func awakeFromNib() {
        super.awakeFromNib()
        if UIDevice.currentDevice().userInterfaceIdiom == .Pad {
            self.clearsSelectionOnViewWillAppear = false
            self.preferredContentSize = CGSize(width: 320.0, height: 600.0)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
   
        url = shareData.url
        username = shareData.username
        password = shareData.password
        refreshData()
        tableView.delegate = self
        tableView.dataSource = self
        //tableView.rowHeight = UITableViewAutomaticDimension
        if let split = splitViewController {
            let controllers = split.viewControllers
             detailViewController =
                controllers[controllers.count-1].topViewController
                as? FourthViewController
        }
        if let splitViewController = self.presentedViewController as? UISplitViewController {
            splitViewController.delegate = self
        }
        
    }
    func refreshData() {
        let loader = GradebookURLLoader()
        
        // Live data URL
        //loader.baseURL = "https://users.csc.calpoly.edu/~bellardo/cgi-bin/grades.json"
        
        // Test data URL
        //loader.baseURL = "https://users.csc.calpoly.edu/~bellardo/cgi-bin/test/grades.json"
        //if loader.loginWithUsername("test", andPassword: "sadf35cx90") {
        loader.baseURL = url
        if loader.loginWithUsername(username, andPassword: password) {
            println("Auth worked!")
            let data = loader.loadDataFromPath("?record=sections", error: nil)
            json = JSON(data: data)
            println("\(json)")
            let num = json["sections"].array?.count
            for i in 0...num!-1 {
                items.append(json["sections"][i]["id"].stringValue)
                details.append(json["sections"][i]["dept"].stringValue + json["sections"][i]["course"].stringValue )
            }
        }
        else {
            println("Auth failed!")
        }
    }
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count;
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var cell:UITableViewCell = self.tableView.dequeueReusableCellWithIdentifier("cell") as UITableViewCell
        
        cell.textLabel?.text = self.items[indexPath.row]
        cell.detailTextLabel?.text = self.details[indexPath.row]
        
        return cell
    }
    var index: Int!
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let val = self.items[indexPath.row]
        println("You selected cell #\(indexPath.row)!")
        
        let num = json["sections"].array?.count
        for i in 0...num!-1 {
            if json["sections"][i]["id"].stringValue == val{
                index = i;
                break;
            }
        }
        self.shareData.term = json["sections"][index]["term"].stringValue
        self.shareData.course = json["sections"][index]["course"].stringValue
    }
}