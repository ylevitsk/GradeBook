#import <Foundation/Foundation.h>


@interface NSString (Base64Encoding)

- (NSString *)base64Encode;

@end
