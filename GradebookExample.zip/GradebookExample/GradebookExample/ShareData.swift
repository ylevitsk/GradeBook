//
//  ShareData.swift
//  GradebookExample
//
//  Created by Moe Wilson on 5/11/15.
//  Copyright (c) 2015 John Bellardo. All rights reserved.
//

import Foundation


class ShareData {
    class var sharedInstance: ShareData {
        struct Static {
            static var instance: ShareData?
            static var token: dispatch_once_t = 0
        }
        
        dispatch_once(&Static.token) {
            Static.instance = ShareData()
        }
        
        return Static.instance!
    }
    
    var username: String! //Some String
    var id: Int!
    var password: String!
    var user: String!
    var url: String!
    var course: String!
    var term:String!
}

